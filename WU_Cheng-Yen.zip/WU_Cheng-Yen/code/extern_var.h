extern int delay_info;
